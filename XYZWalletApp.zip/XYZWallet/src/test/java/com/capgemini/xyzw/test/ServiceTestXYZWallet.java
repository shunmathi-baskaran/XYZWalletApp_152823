package com.capgemini.xyzw.test;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

import com.capgemini.xyzw.service.CustomerService;

/**
 * Unit test for simple App.
 */
public class ServiceTestXYZWallet
{	
	//to validate user name
    @Test
    
    public void testValidateName()
    {
    	CustomerService cust= new CustomerService();
    	boolean actualvalue1=  cust.validateName("shun mathi");
    	assertEquals(true,actualvalue1);
        
    }
   
    //to validate phone number
    @Test
    public void testContactNo()
    {
    	CustomerService cust=new CustomerService();
    	boolean actualvalue2=cust.validateContactNumber("1234556898");
    	assertEquals(true,actualvalue2);
    }
    
    //to validate email id
    @Test
    public void testValidateEmailID()
    {
    	
    	CustomerService cust=new CustomerService();
    	boolean actualvalue3= cust.validateEmailID("jeeve12345+@gmail.com");
    	
    	assertEquals(true,actualvalue3);
    }

}