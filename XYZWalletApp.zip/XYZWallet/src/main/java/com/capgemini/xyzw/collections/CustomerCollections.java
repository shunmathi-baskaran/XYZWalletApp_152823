package com.capgemini.xyzw.collections;

import java.util.HashMap;

import com.capgemini.xyzw.bean.CustomerBean;

public class CustomerCollections implements InterfaceCustomerCollections {
	double bal;
	//CustomerBean bean=new CustomerBean();
HashMap < Integer,CustomerBean> hash=new HashMap<Integer,CustomerBean>();

@Override
public double showBalance(CustomerBean bean)
{
	if(hash.containsKey(bean.getPinNo()))
	{ bal=bean.getBalance();
	}//else return 0;
	return bal;
}
@Override
public CustomerBean addDetails(CustomerBean bean) {
	// TODO Auto-generated method stub
	if(hash.containsKey(bean.getPinNo()))
	{
		return null;
		
	}else{
     hash.put(bean.getPinNo(),bean);

	System.out.println(bean.toString());
	return bean;}
	
	
}

@Override
public double depositAmount(CustomerBean bean,double amt) {
	// TODO Auto-generated method stub
	if(hash.containsKey(bean.getPinNo()))
	{ bal=bean.getBalance()+amt;
	 bean.setBalance(bal);
	 System.out.println("Rs "+ amt +" is deposited to the account "+bean.getAccountNo());
	}
		return bal;
	
 //return bal;
   
}

@Override
public double withdrawAmount(CustomerBean bean,double amt) {
	// TODO Auto-generated method stub
	if(hash.containsKey(bean.getPinNo()))
	{
		if(amt>bal)
		{   
			System.out.println("Withdrawal cannot be done");
			System.out.println("Insufficient balance");
		}
		else
		{
		bal=bean.getBalance()-amt;
		bean.setBalance(bal);
		System.out.println("Rs "+ amt +" is withdrawed from the account "+bean.getAccountNo());
		}
		return bal;
	}
	else
	return 0;
	 
	
}
public void transferAmount(CustomerBean bean2,int tPin,CustomerBean bean,double amt) {
	// TODO Auto-generated method stub
	if(hash.containsKey(bean.getPinNo()))
	{
		double balD=bean.getBalance()+amt;
	  bean.setBalance(balD);
	  hash.put(tPin,bean);
	  System.out.println("Rs "+ amt +" is deposited to the account ");
	  System.out.println("balance is"+balD);
	  //System.out.println("The "+amt+"is transferred to "+bean2.getUserName());
		
	 double balW=bean2.getBalance()-amt;
	  bean2.setBalance(balW);
	  hash.put(bean2.getPinNo(),bean2);
	  System.out.println("Rs "+ amt +" is withdrawed from your account");
	  System.out.println("balance is"+balW);
	}
	 
}
public CustomerBean getBean(int tPin) {
	// TODO Auto-generated method stub
	 return hash.get(tPin);
	
}
public CustomerBean validateLogin(int pinNo, String userName) {
	// TODO Auto-generated method stub
	if(hash.containsKey(pinNo) && hash.get(pinNo).getUserName().equals(userName))
		return hash.get(pinNo);
	return  null;
}
}

