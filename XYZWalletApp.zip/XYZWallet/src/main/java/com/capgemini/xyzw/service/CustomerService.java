package com.capgemini.xyzw.service;

import com.capgemini.xyzw.bean.CustomerBean;
import com.capgemini.xyzw.collections.CustomerCollections;

public class CustomerService implements InterfaceCustomerservice {

static String namePattern="[a-zA-Z]{1,}[\\s][a-zA-Z]{1,}|[a-zA-Z]{1,}";
static String contactPattern="[0-9]{10}";
static String emailIDPattern="[a-zA-Z0-9#!'+-?={$%}^&*._()]{1,}[@]{1}[a-zA-Z.]{1,}";


CustomerCollections col;
public CustomerService() {
	col=new CustomerCollections();
}
CustomerBean bean=new CustomerBean();


public boolean validateName(String name)
{  boolean flag1=false;
	if(name.matches(namePattern))
	{
		flag1=true;
	}
	return flag1;	
}


public boolean validateContactNumber(String contactNo) {
	// TODO Auto-generated method stub
	boolean flag2=false;
	if(contactNo.matches(contactPattern))
	{
		flag2=true;
	
	}return flag2;
}


public boolean validateEmailID(String emailID) {
	// TODO Auto-generated method stub
	boolean flag3=false;
	if(emailID.matches(emailIDPattern))
	{
		flag3=true;
	
	}return flag3;
}

@Override
public CustomerBean addDetailsToCollections(CustomerBean bean) {
	// TODO Auto-generated method stub
	//  CustomerBean bean1= col.addDetails(bean);
	return col.addDetails(bean);  
}

@Override
public double depositAmt(CustomerBean bean, double amt) {
	return col.depositAmount(bean,amt);
}

@Override
public double withdrawAmt(CustomerBean bean,double amt) {
	// TODO Auto-generated method stub
	return col.withdrawAmount(bean,amt);
}


public boolean validatePinNo(CustomerBean b2,int pinNo) {
	// TODO Auto-generated method stub
	boolean flag4=false;
	System.out.println(b2.getPinNo());
	if(pinNo==(b2.getPinNo())){
				
		flag4=true;
	}
	return flag4;

}

@Override
public double showBal(CustomerBean bean) {
	// TODO Auto-generated method stub
	return col.showBalance(bean);
	
}


public void transferAmt(CustomerBean bean,CustomerBean bean2, int tPin, double amt) {
	// TODO Auto-generated method stub
	col.transferAmount(bean,tPin,bean2, amt);
	
}


public CustomerBean validateLogin(int pinNo,String userName) {
	// TODO Auto-generated method stub
	
	return col.validateLogin(pinNo,userName);

	
}
public CustomerBean getBean(int tPin){
	 return col.getBean(tPin);
}

}
