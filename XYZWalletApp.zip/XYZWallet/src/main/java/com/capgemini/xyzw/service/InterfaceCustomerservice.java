package com.capgemini.xyzw.service;

import com.capgemini.xyzw.bean.CustomerBean;

public interface InterfaceCustomerservice {
	public CustomerBean addDetailsToCollections(CustomerBean bean);
	double depositAmt(CustomerBean bean, double amt);
	double withdrawAmt(CustomerBean bean, double amt);
	double showBal(CustomerBean bean);
	public CustomerBean validateLogin(int pinNo, String userName);
	

}
