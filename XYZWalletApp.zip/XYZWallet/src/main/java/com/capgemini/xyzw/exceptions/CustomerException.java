package com.capgemini.xyzw.exceptions;

public class CustomerException extends Exception {

	String message;
	
	public void XYZWalletException(String msg)
	{
		message=msg;
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}

}
