package com.capgemini.xyzw.collections;

import com.capgemini.xyzw.bean.CustomerBean;

public interface InterfaceCustomerCollections {

	double showBalance(CustomerBean bean);
	CustomerBean addDetails(CustomerBean bean);
	double withdrawAmount(CustomerBean bean, double amt);
	double depositAmount(CustomerBean bean, double amt);
	public CustomerBean validateLogin(int pinNo, String userName);
	

}
